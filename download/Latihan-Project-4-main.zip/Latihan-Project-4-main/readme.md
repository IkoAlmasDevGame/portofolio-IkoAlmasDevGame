# Studi kasus toko

1. Fix no Bug
2. Bisa Update, Hapus, dan Tambah Data untuk Lihat Data Barang kaya tidak perlu karena sudah terlihat dari data Table
3. Enjoy The Coding PHP Native Bro and sister

*SEE YOU NEXT TIME*