<?php 
require_once("../ui/header.php");
require_once("../ui/navbar.php");
?>

<?php 
require_once("../ui/footer.php");
?>