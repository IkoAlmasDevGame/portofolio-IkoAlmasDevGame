<?php 

function base($url){
    $link = "http://localhost/Latihan-Project-6/".$url;
    return $link;
}

?>