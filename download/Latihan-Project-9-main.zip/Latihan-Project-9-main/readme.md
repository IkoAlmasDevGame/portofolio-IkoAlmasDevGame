# Latihan Project 9

<h3 style="font-size:medium; font-family:sans-serif; font-wieght:500;">Latihan Project 9</h3>
<span style="font-size:16px; font-family:sans-serif; color:white;">
<p>Tema : Pembuatan Website Sekolah</p>
<!-- CSS dan JS Bootstrap -->
<p>JS dan CSS menggunakan website dari https://getbootstrap.com/docs/5.3/getting-started/introduction/</p>
<!-- JS dan CSS -->
<p>CSS dataTable Bootstrap dari https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css</p>
<p>JS dataTable Bootstrap 1 menggunakan website dari https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js</p>
<p>JS dataTable Bootstrap 2 menggunakan website dari https://cdn.datatables.net/1.13.7/js/jquery.dataTables.js</p>
<p>JS Chart menggunakan website dari https://cdn.jsdelivr.net/npm/chart.js</p>
<p>JS Query menggunakan website dari https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js</p>
<!-- PooperJS -->
<p>JS Pooper menggunakan website dari https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js</p>
<ol type="1">
    <li>Folder Admin :</li>
    <ol type="a">
        <li>Absensi</li>
        <li>Auth</li>
        <li>Guru</li>
        <li>Kelas</li>
        <li>Dashboard</li>
        <li>Laporan</li>
        <li>Pelajaran</li>
        <li>Settings</li>
        <li>Siswa</li>
        <li>Pembayaran</li>
        <li>Ui</li>
        <li>Pendaftaran</li>
    </ol>
    <li>Folder Siswa</li>
    <ol type="a">
        <li>Absensi</li>
        <li>Auth</li>
        <li>Dashboard</li>
        <li>Laporan</li>
        <li>Pelajaran</li>
        <li>Settings</li>
        <li>Ui</li>
    </ol>
    <li>Folder Asset</li>
    <ol type="a">
        <li>Docs</li>
        <li>Image</li>
        <li>Icon</li>
    </ol>
</ol>
</span>
<footer>@copyright belajar bersama by IkoAlmasDevGame</footer>