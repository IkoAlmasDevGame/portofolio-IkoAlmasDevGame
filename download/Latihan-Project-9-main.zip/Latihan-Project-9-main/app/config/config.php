<?php 

function baseurl($url):string {
    $link = "http://localhost/Latihan-Project-8/".$url;
    return $link;
}

function baseurl2($url2):string {
    $link2 = "http://localhost/native/Latihan-Project-8/".$url2;
    return $link2;
}

?>