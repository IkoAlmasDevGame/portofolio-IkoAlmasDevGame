<script src="<?=base('dist/modules/all.min.js')?>" lang="javascript"></script>
<script src="<?=base('dist/modules/custom.js')?>" lang="javascript"></script>
<script src="<?=base('dist/modules/moment.min.js')?>" lang="javascript"></script>
<script src="<?=base('dist/modules/bootstrap.bundle.js')?>" lang="javascript"></script>
<script src="<?=base('dist/modules/bootstrap.js')?>" lang="javascript"></script>
<script src="<?=base('dist/modules/popper.min.js')?>" lang="javascript"></script>
<script src="<?=base('dist/modules/jquery-3.3.1.min.js')?>" lang="javascript"></script>
<script src="<?=base('dist/modules/stisla.js')?>" lang="javascript"></script>
<script src="<?=base('dist/modules/jquery.nicescroll.min.js')?>" lang="javascript"></script>
<script src="<?=base('dist/modules/scripts.js')?>" lang="javascript"></script>
<script src="<?=base('dist/modules/jquery.dataTables.min.js')?>"></script>
<script src="<?=base('dist/modules/dataTables.bootstrap4.min.js')?>"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js" lang="javascript"></script>

<script type="text/javascript">
//datatable
    $(function() {
        $("#example1").DataTable();
        $('#example2').DataTable();
    });
   </script>
</body>
</html>