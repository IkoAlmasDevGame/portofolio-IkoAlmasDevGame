# salon v.1.2.1

1. Sudah ada transaksi kasir untuk pesan secara manual di salon heieyelash studio
2. data sudah terkoneksi ketika print pembayaran kasir
3. terdapat laporan keuangan haieyelash studio
