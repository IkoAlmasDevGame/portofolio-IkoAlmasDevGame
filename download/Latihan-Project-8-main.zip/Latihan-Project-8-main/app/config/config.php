<?php 

function base($url):string{
    $link = "http://localhost/Latihan-Project-8/".$url;
    return $link;
}

?>