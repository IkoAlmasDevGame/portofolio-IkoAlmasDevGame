# Latihan - Project - 8

<span>
<h3 style="text-align:start;">Tema Bebas 3</h3>
<p>Tema Bebas 3 ini sudah ada beberapa folder + file untuk kalian coba</p>
<ol type="1">
     <li>Admin : Auth, Dashboard, Ui</li>
     <li>Non Admin / Pelanggan : Auth, Dashboard, Ui</li>
   </ol>
<p>Masing - masing folder terdapat file di dalam folder</p>
<p>Berimajinasi saja dan css + js menggunakan bootstrap 5.3</p>
<p>Koneksi database ini menggunakan PDO</p>
</span>