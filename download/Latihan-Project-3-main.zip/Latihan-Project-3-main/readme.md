# PHP Native Message By PHP non PHPEmailer

<img src="assets/thumbnail-message.PNG" styl="width: 100%; display:block;" alt="thumbnail">

1. sudah by php email non phpemailer
2. bisa dites by message buatan sendiri emailnya
3. untuk menjalankan online semetera menggunakan ngrok.exe