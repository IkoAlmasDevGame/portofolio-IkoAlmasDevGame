<?php 
error_reporting(0);
$conn = mysqli_connect("localhost", "root", "", "db_message") or die("Failed connection database : ".mysqli_connect_errno());
?>