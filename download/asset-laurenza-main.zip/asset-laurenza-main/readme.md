# PT HUTAM KARYA

versi ini menggunakan versi 1.2 karena ini sudah ada update terbaru dari PT Hutama Karya.

Update Terbaru v1.2 :
- Bisa menggunakan userEmail dan username untuk login, dan password harus sama
- bisa menggunakan filter untuk mencari data
- sudah ada foto di bagian dashboard awal supaya lebih menarik lagi
- tidak ada bug pada page Request Approve dan Master Approve
- sudah ada data list user pada manager
- sudah ada data default foto ketika register
